<?php
include_once 'dashcontroller.php';
include_once 'dashctrl.php';
include_once 'authcontroll.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// session_start();
?>