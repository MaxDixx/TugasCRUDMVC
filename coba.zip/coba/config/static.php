<?php
require_once 'env.php';

define('BASEURL', $_ENV['BASEURL']);
define('BASEDIR', $_ENV['BASEDIR']);

?>